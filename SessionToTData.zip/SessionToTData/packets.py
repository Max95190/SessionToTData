import os
os.system("pip install asyncio")
os.system("pip install opentele")
os.system("pip install telethon")